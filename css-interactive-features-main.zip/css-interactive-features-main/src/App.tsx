import React, { lazy } from "react";
import logo from "./logo.svg";
import "./App.css";
import { Route, Routes } from "react-router-dom";

const FeatureSample = lazy(
  () => import("./features/sample-feature/Component1")
);

function App() {
  return (
    <div className="App">
      <header>I am a header</header>
      <Routes>
        <Route path="/feature-a" element={<FeatureSample />} />
      </Routes>
    </div>
  );
}

export default App;
