import "./Component1.css";

export default function Component1() {
  return <div>Component1</div>;
}
