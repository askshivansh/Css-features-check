/**
 * @param string - Input to the method
 * @returns Stirng with first letter capitalized
 * @description Capitalize the first letter of the string
 */

export const capitalize = (string: string): string => {
  return string?.charAt(0).toUpperCase() + string?.slice(1);
};
